import openai
import os

def generate_article(title: str, keywords: str) -> str:
    openai.api_key = os.getenv("OPENAI_API_KEY")
    prompt = f"""
Напиши SEO-оптимизированную статью на тему: "{title}"
Ключевые слова: {keywords}
Структура: введение, 2-3 смысловых блока, заключение. Стиль: информационный, доступный, техничный.
    """
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Ты опытный копирайтер для блога технологичного бренда."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7,
        max_tokens=1000
    )
    return response.choices[0].message.content.strip()
