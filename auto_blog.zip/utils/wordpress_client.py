import os
import requests
import base64

def publish_to_wordpress(title: str, content: str) -> str:
    url = f"{os.getenv('WP_SITE_URL')}/wp-json/wp/v2/posts"
    credentials = f"{os.getenv('WP_USERNAME')}:{os.getenv('WP_PASSWORD')}"
    token = base64.b64encode(credentials.encode()).decode()
    headers = {
        "Authorization": f"Basic {token}",
        "Content-Type": "application/json"
    }
    data = {
        "title": title,
        "content": content,
        "status": "publish"
    }
    response = requests.post(url, json=data, headers=headers)
    if response.status_code == 201:
        return response.json().get("link")
    else:
        raise Exception(f"Ошибка публикации: {response.text}")
