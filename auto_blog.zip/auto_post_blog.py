import os
from dotenv import load_dotenv
from datetime import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from utils.gpt_generator import generate_article
from utils.wordpress_client import publish_to_wordpress
from utils.telegram_notify import send_telegram_message

# === Загрузка переменных окружения ===
load_dotenv()

# === Настройка Google Sheets ===
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name(
    os.getenv("GOOGLE_SERVICE_ACCOUNT_FILE"), scope)
client = gspread.authorize(creds)
sheet = client.open_by_key(os.getenv("GOOGLE_SHEET_ID")).worksheet(os.getenv("GOOGLE_SHEET_TAB_NAME"))

# === Получение данных ===
rows = sheet.get_all_records()

today = datetime.now().strftime("%Y-%m-%d")

for i, row in enumerate(rows):
    date = row.get("Дата публикации")
    title = row.get("Тема")
    keywords = row.get("Ключевые слова")
    status = row.get("Статус", "").lower()
    comment = row.get("Комментарии", "")

    if date <= today and status == "pending":
        print(f"🔄 Обработка темы: {title}")
        try:
            content = generate_article(title, keywords)
            link = publish_to_wordpress(title, content)
            message = f"✅ Статья опубликована: <b>{title}</b>\n🔗 {link}\n📝 {comment}"
            send_telegram_message(message)
            sheet.update_cell(i + 2, 4, "published")  # Обновляет статус
        except Exception as e:
            send_telegram_message(f"❌ Ошибка публикации статьи "{title}": {e}")
